package com.example.demo.service;

import com.example.demo.entity.music;

public interface MusicsService {

	Iterable<music> findAll();
	void insertMusic(music music);
}
