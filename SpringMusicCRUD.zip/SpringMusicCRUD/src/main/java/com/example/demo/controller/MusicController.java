package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.entity.music;
import com.example.demo.form.MusicForm;
import com.example.demo.service.MusicsService;

@Controller
public class MusicController {
	
	@Autowired
	MusicsService service;
	
	@GetMapping("menu")
	public String menuView() {
		return "menu";
	}
	
	@PostMapping(value="music", params="list")
	public String listView(Model model) {
		Iterable<music> list = service.findAll();
		model.addAttribute("list", list);
		return "list";
	}
	
	@PostMapping(value="music",params="registration")
	public String memberInputView() {
		return "registration";
	}
	
	@PostMapping(value="music",params="confirmation")
	public String memberConfirmationView(MusicForm f) {
		return "confirmation";
	}
	
	@PostMapping(value="music",params="insert")
	public String musicConfirmView(MusicForm f) {
		System.out.println(f);
		music music = new music(f.getSong_id(),f.getSong_name(),f.getSinger());
		System.out.println(music);
		service.insertMusic(music);
		return "complete";
	}
	
	@PostMapping(value="music",params="update")
	public String musicUpdateView() {
		return "update";
	}
	
	@PostMapping(value="music",params="input")
	public String musicInputView() {
		return "input";
	}
	
	@PostMapping(value="music",params="delete")
	public String musicDeleteView() {
		return "delete";
	}
	
	@PostMapping(value="music", params="menu")
    public String menuRedirect() {
        return "menu";
    }
	
}
