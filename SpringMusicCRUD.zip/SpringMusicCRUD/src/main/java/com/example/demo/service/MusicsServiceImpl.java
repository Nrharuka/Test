package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.music;
import com.example.demo.repository.MusicsCrudRepository;

@Service
public class MusicsServiceImpl implements MusicsService{
	@Autowired
	MusicsCrudRepository repository;
	
	@Override
	public Iterable<music> findAll() {
		return repository.findAll();
	}
	
	@Override
	public void insertMusic(music music) {
		repository.save(music);
	}

}
